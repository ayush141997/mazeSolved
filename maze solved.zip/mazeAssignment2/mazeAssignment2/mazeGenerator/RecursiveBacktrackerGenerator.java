package mazeGenerator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import maze.Cell;
import maze.Maze;
import static maze.Maze.EAST;
import static maze.Maze.HEX;
import static maze.Maze.NORMAL;
import static maze.Maze.NORTH;
import static maze.Maze.NORTHEAST;
import static maze.Maze.NORTHWEST;
import static maze.Maze.SOUTH;
import static maze.Maze.SOUTHEAST;
import static maze.Maze.SOUTHWEST;
import static maze.Maze.TUNNEL;
import static maze.Maze.WEST;

public class RecursiveBacktrackerGenerator implements MazeGenerator {
protected boolean isIn(int r, int c,Maze maze) {
		return r >= 0 && r < maze.sizeR && c >= (r + 1) / 2 && c < maze.sizeC + (r + 1) / 2;
	}
	private int[] random(int i,int j,int in,Maze maze,int[] dir,int[][] visited){
            
            int a,b,c,d,flag=0;
            int[] ret=new int[3];
            Random rand=new Random();
            while(flag==0){
                      int dirIn=rand.nextInt(in);
                      a=i+Maze.deltaR[dir[dirIn]];
                      b=j+Maze.deltaC[dir[dirIn]];
                      if(maze.type==NORMAL){
                      if(a >= 0 && a < maze.sizeR && b >= 0 && b < maze.sizeC){
                      if(visited[a][b]==0){
                          Cell cell=maze.map[i][j];
                          cell.wall[dir[dirIn]].present=false;
                          visited[a][b]=1;
                          maze.drawFtPrt(cell);
                          i=a;
                          j=b;
                          flag=2;
                          break;
                      }
                      else{
                          for (int k = 0; k < in; k++) {
                              c=i+Maze.deltaR[dir[k]];
                      d=j+Maze.deltaC[dir[k]];
                      if(c >= 0 && c < maze.sizeR && d >= 0 && d < maze.sizeC)
                      { if((visited[c][d]==1))
                              {
                                  flag=1;
                                 
                              }
                              else{
                                  flag=0;
                                  break;
                              }
                          }
                      }
                      }
                  }
                      }
                      else{
                          if(a >= 0 && a < maze.sizeR && b >= (a + 1) / 2 && b < maze.sizeC + (a + 1) / 2){
                      if(visited[a][b]==0){
                          Cell cell=maze.map[i][j];
                          cell.wall[dir[dirIn]].present=false;
                          visited[a][b]=1;
                          maze.drawFtPrt(cell);
                          i=a;
                          j=b;
                          flag=2;
                          break;
                      }
                      else{
                          for (int k = 0; k < in; k++) {
                              c=i+Maze.deltaR[dir[k]];
                      d=j+Maze.deltaC[dir[k]];
                      if(c >= 0 && c < maze.sizeR && d >= (c + 1) / 2 && d < maze.sizeC + (c + 1) / 2)
                      { if((visited[c][d]==1))
                              {
                                  flag=1;
                                 
                              }
                              else{
                                  flag=0;
                                  break;
                              }
                          }
                      }
                      }
                  }
                      }
                  }
            ret[0]=i;
            ret[1]=j;
            ret[2]=flag;
            visited[i][j]=1;
            Cell cell=maze.map[i][j];
            maze.drawFtPrt(cell);
            return ret;
        }
	@Override
	public void generateMaze(Maze maze) {
            Cell b;
            List<Cell> z=new ArrayList<>();
            Random rand=new Random();
            int p=0,flag=0;
            int dir[]=null,in=0,i = 0,j = 0;
            int[][] visited=null;
                switch (maze.type) {
                    case NORMAL:
                            dir=new int[]{EAST,NORTH,WEST,SOUTH};
                            in=4;
                            visited=new int[maze.sizeR][maze.sizeC];
                            for (int i1 = 0; i1 < maze.sizeR; i1++) {
                                for (int j1 = 0; j1 < maze.sizeC; j1++) {
                                    visited[i1][j1]=0;
                                }
                            }
                            i=rand.nextInt(maze.sizeR);
                            j=rand.nextInt(maze.sizeC);
                            break;
                    case HEX:
                            dir=new int[]{EAST,NORTHEAST,NORTHWEST,WEST,SOUTHWEST,SOUTHEAST};
                            in=6;
                            visited=new int[maze.sizeR][maze.sizeC + (maze.sizeR + 1) / 2];
                            for (int i1 = 0; i1 < maze.sizeR; i1++){
                                for (int j1 = (i1 + 1) / 2; j1 < maze.sizeC + (i1 + 1) / 2; j1++) {
                                    if (!isIn(i1, j1,maze))
                                        continue;
                                    visited[i1][j1]=0;
                                }
                            }
                            i=rand.nextInt(maze.sizeR);
                            j=rand.nextInt(maze.sizeC)+((i+1)/2);
                            break;
                    case TUNNEL: 
                            maze.type=NORMAL;
                            dir=new int[]{EAST,NORTH,WEST,SOUTH};
                            in=4;
                            visited=new int[maze.sizeR][maze.sizeC];
                            for (int i1 = 0; i1 < maze.sizeR; i1++) {
                                for (int j1 = 0; j1 < maze.sizeC; j1++) {
                                    visited[i1][j1]=0;
                                }
                            }
                            i=rand.nextInt(maze.sizeR);
                            j=rand.nextInt(maze.sizeC);
                            break;
                    default:
                            break;
                }
                
                Cell start=maze.map[i][j];
                visited[i][j]=1;
                z.add(start);
            while(!z.isEmpty())
            {
                p=z.size()-1;
                b=z.get(p);
                i=b.r;
                j=b.c;
                int[] random = random(i,j,in,maze,dir,visited);
                i=random[0];
                j=random[1];
                flag=random[2];
                if(flag==2){
                    z.add(maze.map[i][j]);
                }
                else if(flag==1){
                    z.remove(maze.map[i][j]);
                }
            }
	}//end of generateMaze()
} // end of class RecursiveBacktrackerGenerator
