package mazeGenerator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import maze.Cell;
import maze.Maze;
import static maze.Maze.EAST;
import static maze.Maze.HEX;
import static maze.Maze.NORMAL;
import static maze.Maze.NORTH;
import static maze.Maze.NORTHEAST;
import static maze.Maze.NORTHWEST;
import static maze.Maze.SOUTH;
import static maze.Maze.SOUTHEAST;
import static maze.Maze.SOUTHWEST;
import static maze.Maze.TUNNEL;
import static maze.Maze.WEST;

public class ModifiedPrimsGenerator implements MazeGenerator {

	@Override
	public void generateMaze(Maze maze) {
		// TODO Auto-generated method stub
                int in = 0;
                Cell cell,c,b = null;
                List<Cell> z=new ArrayList<>();
                List<Cell> f=new ArrayList<>();
                Random rand=new Random();
                int i=0;
                int j=0;
                int dir[]=null;
                switch (maze.type) {
                    case NORMAL:
                        dir=new int[]{EAST,NORTH,WEST,SOUTH};
                        in=4;
                        i=rand.nextInt(maze.sizeR);
                        j=rand.nextInt(maze.sizeC);
                        break;
                    case HEX:
                        dir=new int[]{EAST,NORTHEAST,NORTHWEST,WEST,SOUTHWEST,SOUTHEAST};
                        in=6;
                        i=rand.nextInt(maze.sizeR);
                        j=rand.nextInt(maze.sizeC)+((i+1)/2);
                        break;
                    default:
                        break;
                }
                Cell start=maze.map[i][j];
                z.add(start);
                for (int k = 0; k < in; k++) {
                    
                    if(start.neigh[dir[k]]!=null){
                        cell=start.neigh[dir[k]];
                        f.add(cell);
                    }
                }
                int r,s,flag=0;
                while(z.size()!=(maze.sizeR*maze.sizeC))
                {
                    r=rand.nextInt(f.size());
                    c=f.get(r);
                    f.remove(r);
                    while(flag==0){
                        s=rand.nextInt(z.size());
                        b=z.get(s);
                        for (int k = 0; k < in; k++) {
                            cell=c.neigh[dir[k]];
                            if(cell==b){
                                c.wall[dir[k]].present=false;
                                flag=1;
                                break;
                            }
                        }
                    }
                    flag=0;
                    z.add(c);
                    for (int k = 0; k < in; k++) {
                        cell=c.neigh[dir[k]];
                        if(!(z.contains(cell)||f.contains(cell)||(cell==null))){
                            f.add(cell);
                        }
                    }
                }
                
	} // end of generateMaze()

} // end of class ModifiedPrimsGenerator
