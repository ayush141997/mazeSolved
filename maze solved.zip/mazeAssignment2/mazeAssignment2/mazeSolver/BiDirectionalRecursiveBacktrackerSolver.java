package mazeSolver;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import maze.Cell;
import maze.Maze;
import static maze.Maze.EAST;
import static maze.Maze.HEX;
import static maze.Maze.NORMAL;
import static maze.Maze.NORTH;
import static maze.Maze.NORTHEAST;
import static maze.Maze.NORTHWEST;
import static maze.Maze.SOUTH;
import static maze.Maze.SOUTHEAST;
import static maze.Maze.SOUTHWEST;
import static maze.Maze.TUNNEL;
import static maze.Maze.WEST;
import maze.StdDraw;

/**
 * Implements the BiDirectional recursive backtracking maze solving algorithm.
 */
public class BiDirectionalRecursiveBacktrackerSolver implements MazeSolver {

        public int cell=0,solved=0;
	@Override
	public void solveMaze(Maze maze) {
		// TODO Auto-generated method stub
            Cell b;
            int celle=0,cellex=0;
            List<Cell> entry=new ArrayList<>();
            List<Cell> exit=new ArrayList<>();
            Random rand=new Random();
            int dir[]=null,in=0,numT=0;
            int[][] visited1=null;
            int[][] visited2=null;
                switch (maze.type) {
                    case NORMAL:
                            dir=new int[]{EAST,NORTH,WEST,SOUTH};
                            in=4;
                            visited1=new int[maze.sizeR][maze.sizeC];
                            for (int i1 = 0; i1 < maze.sizeR; i1++) {
                                for (int j1 = 0; j1 < maze.sizeC; j1++) {
                                    visited1[i1][j1]=0;
                                }
                            }
                            visited2=new int[maze.sizeR][maze.sizeC];
                            for (int i1 = 0; i1 < maze.sizeR; i1++) {
                                for (int j1 = 0; j1 < maze.sizeC; j1++) {
                                    visited2[i1][j1]=0;
                                }
                            }
                            break;
                    case HEX:
                            dir=new int[]{EAST,NORTHEAST,NORTHWEST,WEST,SOUTHWEST,SOUTHEAST};
                            in=6;
                            visited1=new int[maze.sizeR][maze.sizeC + (maze.sizeR + 1) / 2];
                            for (int i1 = 0; i1 < maze.sizeR; i1++){
                                for (int j1 = (i1 + 1) / 2; j1 < maze.sizeC + (i1 + 1) / 2; j1++) {
                                    if (!isInHex(i1, j1,maze))
                                        continue;
                                    visited1[i1][j1]=0;
                                }
                            }
                            visited2=new int[maze.sizeR][maze.sizeC + (maze.sizeR + 1) / 2];
                            for (int i1 = 0; i1 < maze.sizeR; i1++){
                                for (int j1 = (i1 + 1) / 2; j1 < maze.sizeC + (i1 + 1) / 2; j1++) {
                                    if (!isInHex(i1, j1,maze))
                                        continue;
                                    visited2[i1][j1]=0;
                                }
                            }
                            break;
                    case TUNNEL:
                            maze.type=NORMAL;
                            dir=new int[]{EAST,NORTH,WEST,SOUTH};
                            in=4;
                            numT=maze.sizeTunnel;
                            visited1=new int[maze.sizeR][maze.sizeC];
                            for (int i1 = 0; i1 < maze.sizeR; i1++) {
                                for (int j1 = 0; j1 < maze.sizeC; j1++) {
                                    visited1[i1][j1]=0;
                                }
                            }
                            visited2=new int[maze.sizeR][maze.sizeC];
                            for (int i1 = 0; i1 < maze.sizeR; i1++) {
                                for (int j1 = 0; j1 < maze.sizeC; j1++) {
                                    visited2[i1][j1]=0;
                                }
                            }
                            break;
                    default:
                            break;
                }
                Cell en=maze.entrance;
                visited1[en.r][en.c]=1;
                celle++;
                entry.add(en);
                drawFtPrt1(en,maze);
                Cell ex=maze.exit;
                visited2[ex.r][ex.c]=1;
                cellex++;
                exit.add(ex);
                drawFtPrt2(ex,maze);
                int flag1=0,flag2=0;
                while(en!=ex){
                    while(flag1==0){
                        int i=rand.nextInt(in);
                        //System.out.println("i: "+i);
                        if((!en.wall[dir[i]].present)&&(isInNorm(en.neigh[dir[i]].r,en.neigh[dir[i]].c,maze)||isInHex(en.neigh[dir[i]].r,en.neigh[dir[i]].c,maze))){
                            if(visited1[en.neigh[dir[i]].r][en.neigh[dir[i]].c]==0){
                                visited1[en.neigh[dir[i]].r][en.neigh[dir[i]].c]=1;
                                celle++;
                                entry.add(en.neigh[dir[i]]);
                                en=en.neigh[dir[i]];
                                drawFtPrt1(en,maze);
                                break;
                            }
                            else{
                                for (int k = 0; k < in; k++) {
                                    if((!en.wall[dir[k]].present)&&(isInNorm(en.neigh[dir[k]].r,en.neigh[dir[k]].c,maze)||isInHex(en.neigh[dir[k]].r,en.neigh[dir[k]].c,maze))){
                                        if(visited1[en.neigh[dir[k]].r][en.neigh[dir[k]].c]==1){
                                            flag1=1;
                                        }
                                        else{
                                            flag1=0;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if(flag1==1){
                        entry.remove(en);
                        if(!entry.isEmpty()){
                            en=entry.get(entry.size()-1);
                            flag1=0;
                        }
                        
                    }
                    
                    while(flag2==0){
                        int j=rand.nextInt(in);
                        if((!ex.wall[dir[j]].present)&&(isInNorm(ex.neigh[dir[j]].r,ex.neigh[dir[j]].c,maze)||isInHex(ex.neigh[dir[j]].r,ex.neigh[dir[j]].c,maze))){
                            if(visited2[ex.neigh[dir[j]].r][ex.neigh[dir[j]].c]==0){
                                visited2[ex.neigh[dir[j]].r][ex.neigh[dir[j]].c]=1;
                                cellex++;
                                exit.add(ex.neigh[dir[j]]);
                                ex=ex.neigh[dir[j]];
                                drawFtPrt2(ex,maze);
                                break;
                            }
                            else{
                                for (int k = 0; k < in; k++) {
                                    if((!ex.wall[dir[k]].present)&&(isInNorm(ex.neigh[dir[k]].r,ex.neigh[dir[k]].c,maze)||isInHex(ex.neigh[dir[k]].r,ex.neigh[dir[k]].c,maze))){
                                        if(visited2[ex.neigh[dir[k]].r][ex.neigh[dir[k]].c]==1){
                                            flag2=1;
                                        }
                                        else{
                                            flag2=0;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if(flag2==1){
                        exit.remove(ex);
                        if(!exit.isEmpty()){
                            ex=exit.get(exit.size()-1);
                            flag2=0;
                        }
                        
                    }
                    if(maze.type==NORMAL){
                        for (int i1 = 0; i1 < maze.sizeR; i1++) {
                                for (int j1 = 0; j1 < maze.sizeC; j1++) {
                                    if(visited1[i1][j1]==1 &&
                                    visited2[i1][j1]==1){
                                        en=maze.map[i1][j1];
                                        ex=maze.map[i1][j1];
                                        break;
                                    }
                                }
                            }
                    }
                    else if(maze.type==HEX){
                        for (int i1 = 0; i1 < maze.sizeR; i1++){
                                for (int j1 = (i1 + 1) / 2; j1 < maze.sizeC + (i1 + 1) / 2; j1++) {
                                    if (!isInHex(i1, j1,maze))
                                        continue;
                                    if(visited1[i1][j1]==1 &&
                                    visited2[i1][j1]==1){
                                        en=maze.map[i1][j1];
                                        ex=maze.map[i1][j1];
                                        break;
                                    }
                                }
                            }
                    }
                }
                if(en==ex){
                    solved=1;
                }
                cell=celle+cellex;
	} // end of solveMaze()


	@Override
	public boolean isSolved() {
		// TODO Auto-generated method stub
                if(solved==1){
                    return true;
                }
		return false;
	} // end if isSolved()


	@Override
	public int cellsExplored() {
		// TODO Auto-generated method stub
		return cell;
	} // end of cellsExplored()

        protected boolean isInNorm(int r, int c, Maze maze) {
		return r >= 0 && r < maze.sizeR && c >= 0 && c < maze.sizeC;
	}
        protected boolean isInHex(int r, int c,Maze maze) {
		return r >= 0 && r < maze.sizeR && c >= (r + 1) / 2 && c < maze.sizeC + (r + 1) / 2;
	}
        protected void drawFtPrt1(Cell cell,Maze maze) {
 		// draw nothing if visualization is switched off
                if(maze.type==HEX){
                    StdDraw.setPenColor(StdDraw.GRAY);
                    StdDraw.filledCircle(cell.r % 2 * 0.5 + cell.c - (cell.r + 1) / 2 + 0.5, cell.r + 0.5, 0.25);
                }
                else if(maze.type==NORMAL){
                    StdDraw.setPenColor(StdDraw.GRAY);
                    StdDraw.filledCircle(cell.c + 0.5, cell.r + 0.5, 0.25);
                }
                
	}
        protected void drawFtPrt2(Cell cell,Maze maze) {
 		// draw nothing if visualization is switched off
		if(maze.type==HEX){
                    StdDraw.setPenColor(StdDraw.GRAY);
                    StdDraw.filledCircle(cell.r % 2 * 0.5 + cell.c - (cell.r + 1) / 2 + 0.5, cell.r + 0.5, 0.25);
                }
                else if(maze.type==NORMAL){
                    StdDraw.setPenColor(StdDraw.GRAY);
                    StdDraw.filledCircle(cell.c + 0.5, cell.r + 0.5, 0.25);
                }
	}
} // end of class BiDirectionalRecursiveBackTrackerSolver
